Compiz Manual Tests
===================

Avoid writing manual tests if you can. Acceptance tests that can be run
on an automatic basis are always preferred.

If getting some part of the code would be too difficult or invasive, then
write a manual test in here so that we can remind ourselves to deploy test
frameworks for the code in quesiton.
